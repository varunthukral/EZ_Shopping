package com.javatpoint.beans;  
  
public class Emp {  
private int id,amount;  
  
private String password,Email,fname,lname,name,message,item,add,currency,newpassword;

 

public String getNewpassword() {
	return newpassword;
}
public void setNewpassword(String newpassword) {
	this.newpassword = newpassword;
}
private float discount;
  
public int getId() {  
    return id;  
}  
public void setId(int id) {  
    this.id = id;  
}  
public String getlname() {  
    return lname;  
}  
public void setlname(String lname) {  
    this.lname = lname;  
}
public String getfname() {  
    return fname;  
}  
public void setfname(String fname) {  
    this.fname = fname;  
}  
public String getEmail() {  
    return Email;  
}  
public void setEmail(String email) {  
    this.Email = email;  
}  
public String getPassword() {  
    return password;  
}  
public void setPassword(String f) {  
    this.password = f;  
}  

public String getname() {  
    return name;  
}  
public void setname(String name) {  
    this.name = name;  
}  
public String getmessage() {  
    return message;  
}  
public void setmessage(String message) {  
    this.message = message;  
}
public String getadd() {  
    return add;  
}  
public void setadd(String add) {  
    this.add = add;  
}
public String getitem() {  
    return item;  
}  
public void setitem(String item) {  
    this.item = item;  
}
public int getamount() {  
    return amount;  
}  
public void setamount(int amount) {  
    this.amount = amount;
}
public float getdiscount() {  
    return discount;  
}  
public void setdiscount(int discount) {  
    this.discount = discount;  
}
public String getcurrency() {  
    return currency;  
}  
public void setcurrency(String currency) {  
    this.currency = currency;  
}


}  